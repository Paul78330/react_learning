import React from 'react';
import Contact from './Contact';

function App() {
  return (
      <Contact />
  );
}

export default App