import React from 'react';
import AnimalFacts from './AnimalFacts';


