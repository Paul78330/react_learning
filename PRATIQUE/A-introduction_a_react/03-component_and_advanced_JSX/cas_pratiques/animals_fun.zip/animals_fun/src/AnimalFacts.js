// Importation des dépendances et des données
import { animals } from './animals';
import React from 'react';

// Titre initial
const title = '';

// Image de fond
const background = <img className="background" alt='ocean' src='/images/ocean.jpg'/>;

// Fonction pour afficher un fait aléatoire sur l'animal cliqué
function displayFact(e){
  
}

// Création des images pour chaque animal
const images = [];



const showBackground = true;


// Composant principal
function AnimalFacts() {
  return (
    <div>
      
    </div>
  );
}

// Exportation du composant pour pouvoir l'utiliser dans d'autres fichiers
export default AnimalFacts;

